package com.example.mp3player

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var lastRequest = 0L

    private val audioPerm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun prefs() = getSharedPreferences("p", MODE_PRIVATE)

    private fun hasAudio() = checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Playback.app = applicationContext

        web = WebView(this)
        web.setBackgroundColor(0xFF0B0B14.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        askPermissions()
    }

    override fun onStart() {
        super.onStart()
        // Повернулись у додаток — віконце більше не потрібне
        PlayerService.instance?.hideOverlay()
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing && prefs().getBoolean("auto", false) &&
            Playback.isPlaying && Settings.canDrawOverlays(this)
        ) {
            PlayerService.instance?.showOverlay()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack ? onBack() : false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (!hasAudio()) need.add(audioPerm)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            lastRequest = System.currentTimeMillis()
            requestPermissions(need.toTypedArray(), 1)
        } else {
            loadMusic()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAudio()) {
            loadMusic()
        } else if (System.currentTimeMillis() - lastRequest < 400) {
            // система не показала вікно — дозвіл заборонено назавжди, відкриваємо налаштування
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        Toast.makeText(this, "Увімкни доступ до музики та файлів", Toast.LENGTH_LONG).show()
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }

    private fun openOverlaySettings() {
        Toast.makeText(this, "Увімкни «Поверх інших додатків»", Toast.LENGTH_LONG).show()
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun loadMusic() {
        if (!hasAudio()) return
        Thread {
            val list = Playback.query(applicationContext)
            runOnUiThread { Playback.setTracks(list) }
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun getTracks(): String {
            val a = JSONArray()
            for (t in Playback.tracks) {
                a.put(JSONObject().put("t", t.title).put("a", t.artist).put("d", t.duration))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun getState(): String = JSONObject()
            .put("ver", Playback.version)
            .put("index", Playback.index)
            .put("playing", Playback.isPlaying)
            .put("pos", Playback.position)
            .put("dur", Playback.duration)
            .put("shuffle", Playback.shuffle)
            .put("repeat", Playback.repeat)
            .put("perm", hasAudio())
            .put("auto", prefs().getBoolean("auto", false))
            .toString()

        @JavascriptInterface
        fun play(i: Int) {
            runOnUiThread {
                PlayerService.send(this@MainActivity, PlayerService.A_PLAY) { putExtra("i", i) }
            }
        }

        @JavascriptInterface
        fun toggle() {
            runOnUiThread {
                if (Playback.current == null && Playback.tracks.isNotEmpty()) {
                    PlayerService.send(this@MainActivity, PlayerService.A_PLAY) { putExtra("i", 0) }
                } else {
                    PlayerService.send(this@MainActivity, PlayerService.A_TOGGLE)
                }
            }
        }

        @JavascriptInterface
        fun next() {
            runOnUiThread { PlayerService.send(this@MainActivity, PlayerService.A_NEXT) }
        }

        @JavascriptInterface
        fun prev() {
            runOnUiThread { PlayerService.send(this@MainActivity, PlayerService.A_PREV) }
        }

        @JavascriptInterface
        fun seek(ms: Int) {
            runOnUiThread { Playback.seek(ms) }
        }

        @JavascriptInterface
        fun shuffle(v: Boolean) {
            Playback.shuffle = v
        }

        @JavascriptInterface
        fun repeat(v: Int) {
            Playback.repeat = v
        }

        @JavascriptInterface
        fun rescan() {
            runOnUiThread {
                if (hasAudio()) loadMusic() else askPermissions()
            }
        }

        @JavascriptInterface
        fun requestAccess() {
            runOnUiThread { askPermissions() }
        }

        @JavascriptInterface
        fun setAuto(v: Boolean) {
            runOnUiThread {
                prefs().edit().putBoolean("auto", v).apply()
                if (v && !Settings.canDrawOverlays(this@MainActivity)) openOverlaySettings()
            }
        }

        @JavascriptInterface
        fun minimize() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    openOverlaySettings()
                    return@runOnUiThread
                }
                val svc = PlayerService.instance
                if (svc == null || Playback.current == null) {
                    Toast.makeText(this@MainActivity, "Спочатку увімкни якусь пісню", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                svc.showOverlay()
                moveTaskToBack(true)
            }
        }
    }
}
