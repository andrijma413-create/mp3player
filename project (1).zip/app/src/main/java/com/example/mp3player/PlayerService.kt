package com.example.mp3player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Size

/**
 * Служба на передньому плані: тримає музику живою у фоні,
 * показує сповіщення з кнопками і керує плаваючим віконцем.
 */
class PlayerService : Service() {

    companion object {
        const val CH = "player"
        const val NID = 1
        const val A_PLAY = "com.example.mp3player.PLAY"
        const val A_TOGGLE = "com.example.mp3player.TOGGLE"
        const val A_NEXT = "com.example.mp3player.NEXT"
        const val A_PREV = "com.example.mp3player.PREV"
        const val A_STOP = "com.example.mp3player.STOP"

        @Volatile var instance: PlayerService? = null

        fun send(ctx: Context, action: String, block: Intent.() -> Unit = {}) {
            val i = Intent(ctx, PlayerService::class.java).setAction(action).apply(block)
            ctx.startForegroundService(i)
        }
    }

    private lateinit var session: MediaSession
    private var overlay: OverlayView? = null
    private var artId = -1L
    private var artBmp: Bitmap? = null

    private val listener: () -> Unit = { refresh() }
    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            Playback.pause()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        Playback.app = applicationContext

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Відтворення музики", NotificationManager.IMPORTANCE_LOW)
        )

        session = MediaSession(this, "Mp3Player")
        session.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { if (!Playback.isPlaying) Playback.toggle() }
            override fun onPause() { if (Playback.isPlaying) Playback.toggle() }
            override fun onSkipToNext() { Playback.next(false) }
            override fun onSkipToPrevious() { Playback.prev() }
            override fun onSeekTo(pos: Long) { Playback.seek(pos.toInt()) }
        })
        session.isActive = true

        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NID, n)
        }

        Playback.listeners.add(listener)
        val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(noisy, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(noisy, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_PLAY -> Playback.playIndex(intent.getIntExtra("i", 0))
            A_TOGGLE -> Playback.toggle()
            A_NEXT -> Playback.next(false)
            A_PREV -> Playback.prev()
            A_STOP -> {
                Playback.listeners.remove(listener)
                Playback.stopAll()
                overlay?.hide()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        refresh()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Playback.listeners.remove(listener)
        try { unregisterReceiver(noisy) } catch (e: Exception) {}
        try { session.release() } catch (e: Exception) {}
        overlay?.hide()
        overlay = null
        instance = null
        super.onDestroy()
    }

    fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        if (overlay == null) overlay = OverlayView(this)
        overlay?.show()
    }

    fun hideOverlay() {
        overlay?.hide()
    }

    private fun refresh() {
        val t = Playback.current
        val playing = Playback.isPlaying

        val md = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, t?.title ?: "MP3 Плеєр")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, t?.artist ?: "")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, t?.duration ?: 0L)
        art(t)?.let { md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) }
        session.setMetadata(md.build())

        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
            PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
            PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                .setState(
                    if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    Playback.position.toLong(),
                    1f
                )
                .build()
        )

        getSystemService(NotificationManager::class.java).notify(NID, buildNotification())
        overlay?.update()
    }

    private fun art(t: Track?): Bitmap? {
        if (t == null) return null
        if (t.id == artId) return artBmp
        var bmp: Bitmap? = null
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                bmp = contentResolver.loadThumbnail(t.uri, Size(512, 512), null)
            } catch (e: Exception) {
                // у файлу немає обкладинки
            }
        }
        if (bmp == null) bmp = ArtGen.make(t.title, 512)
        artId = t.id
        artBmp = bmp
        return bmp
    }

    private fun buildNotification(): Notification {
        val t = Playback.current
        val playing = Playback.isPlaying
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )

        fun act(icon: Int, title: String, action: String, code: Int): Notification.Action {
            val pi = PendingIntent.getService(
                this, code,
                Intent(this, PlayerService::class.java).setAction(action),
                flags
            )
            return Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build()
        }

        val b = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_note)
            .setContentTitle(t?.title ?: "MP3 Плеєр")
            .setContentText(t?.artist ?: "Обери пісню")
            .setContentIntent(open)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .addAction(act(R.drawable.ic_prev, "Назад", A_PREV, 1))
            .addAction(
                act(
                    if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                    if (playing) "Пауза" else "Грати",
                    A_TOGGLE, 2
                )
            )
            .addAction(act(R.drawable.ic_next, "Далі", A_NEXT, 3))
            .addAction(act(R.drawable.ic_close, "Закрити", A_STOP, 4))
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        art(t)?.let { b.setLargeIcon(it) }
        return b.build()
    }
}
