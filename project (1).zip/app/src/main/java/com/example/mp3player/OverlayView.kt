package com.example.mp3player

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Плаваюче віконце поверх інших додатків з кнопками ⏮ ▶/⏸ ⏭. Можна перетягувати. */
class OverlayView(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var cover: TextView? = null
    private var title: TextView? = null
    private var artist: TextView? = null
    private var playBtn: ImageView? = null

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private val lp = WindowManager.LayoutParams(
        dp(270),
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(16)
        y = dp(140)
    }

    private fun iv(res: Int, size: Int, onClick: () -> Unit): ImageView =
        ImageView(ctx).apply {
            setImageResource(res)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply {
                marginStart = dp(8)
                marginEnd = dp(8)
            }
            setOnClickListener { onClick() }
        }

    private fun build(): LinearLayout {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(0xF2191928.toInt())
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0x33FFFFFF)
            }
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val cv = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(10)
                marginEnd = dp(6)
            }
        }
        val tt = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
        }
        val ar = TextView(ctx).apply {
            setTextColor(0xFF9A9AB5.toInt())
            textSize = 12f
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(tt)
        col.addView(ar)

        val open = TextView(ctx).apply {
            text = "↗"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { openApp() }
        }
        val close = iv(R.drawable.ic_close, 32) { hide() }

        header.addView(cv)
        header.addView(col)
        header.addView(open)
        header.addView(close)

        val controls = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        val play = iv(R.drawable.ic_play, 48) { Playback.toggle() }
        play.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF8B5CF6.toInt(), 0xFFEC4899.toInt())
        ).apply { shape = GradientDrawable.OVAL }
        controls.addView(iv(R.drawable.ic_prev, 44) { Playback.prev() })
        controls.addView(play)
        controls.addView(iv(R.drawable.ic_next, 44) { Playback.next(false) })

        r.addView(header)
        r.addView(controls)

        // Перетягування віконця за вільні місця
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(r, lp) } catch (ex: Exception) {}
                }
            }
            true
        }

        cover = cv
        title = tt
        artist = ar
        playBtn = play
        return r
    }

    private fun openApp() {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        ctx.startActivity(i)
        hide()
    }

    fun show() {
        if (root == null) {
            try {
                val r = build()
                wm.addView(r, lp)
                root = r
            } catch (e: Exception) {
                root = null
                return
            }
        }
        update()
    }

    fun hide() {
        root?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        root = null
    }

    fun update() {
        if (root == null) return
        val t = Playback.current
        val name = t?.title ?: "MP3 Плеєр"
        title?.text = name
        artist?.text = t?.artist ?: "Обери пісню"
        cover?.text = ArtGen.letter(name)
        val (c1, c2) = ArtGen.colors(name)
        cover?.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
            .apply { cornerRadius = dp(12).toFloat() }
        playBtn?.setImageResource(if (Playback.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }
}
