package com.example.mp3player

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface

/** Кольорові "обкладинки" з літерою — як у вебверсії плеєра. */
object ArtGen {
    private fun hue(s: String): Int {
        var h = 0
        for (c in s) h = (h * 31 + c.code) % 360
        return h
    }

    fun colors(s: String): Pair<Int, Int> {
        val h = hue(s)
        val c1 = Color.HSVToColor(floatArrayOf(h.toFloat(), 0.65f, 0.90f))
        val c2 = Color.HSVToColor(floatArrayOf(((h + 50) % 360).toFloat(), 0.80f, 0.75f))
        return Pair(c1, c2)
    }

    fun letter(s: String): String =
        if (s.isEmpty()) "♪" else s.substring(0, 1).uppercase()

    fun make(title: String, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val (c1, c2) = colors(title)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Color.WHITE
        tp.textSize = size * 0.45f
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
        val fm = tp.fontMetrics
        canvas.drawText(letter(title), size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, tp)
        return bmp
    }
}
