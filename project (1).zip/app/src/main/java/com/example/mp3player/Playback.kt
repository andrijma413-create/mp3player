package com.example.mp3player

import android.content.ContentUris
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.PowerManager
import android.provider.MediaStore

data class Track(val id: Long, val title: String, val artist: String, val duration: Long) {
    val uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

/** Єдине місце, де живе стан відтворення (черга, MediaPlayer, режими). */
object Playback {
    lateinit var app: Context

    @Volatile var tracks: List<Track> = emptyList()
    @Volatile var version = 0
    @Volatile var index = -1
    @Volatile var shuffle = false
    @Volatile var repeat = 0 // 0 - без повтору, 1 - повторити все, 2 - повторити трек

    private var mp: MediaPlayer? = null
    private var prepared = false
    private var fails = 0
    private var focusReq: AudioFocusRequest? = null
    val listeners = mutableListOf<() -> Unit>()

    val current: Track? get() = tracks.getOrNull(index)
    val isPlaying: Boolean
        get() = try { prepared && mp?.isPlaying == true } catch (e: Exception) { false }
    val position: Int
        get() = try { if (prepared) mp?.currentPosition ?: 0 else 0 } catch (e: Exception) { 0 }
    val duration: Int
        get() = try { if (prepared) mp?.duration ?: 0 else 0 } catch (e: Exception) { 0 }

    private fun notifyChange() {
        listeners.toList().forEach { it() }
    }

    /** Читає всю музику з пам'яті телефону (MediaStore). Викликати у фоновому потоці. */
    fun query(ctx: Context): List<Track> {
        val list = ArrayList<Track>()
        try {
            val proj = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DURATION
            )
            val sel = "${MediaStore.Audio.Media.DURATION} >= 30000 AND " +
                "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
                "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND " +
                "${MediaStore.Audio.Media.IS_ALARM} = 0"
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Невідомий виконавець"
                    list.add(Track(c.getLong(0), c.getString(1) ?: "Без назви", artist, c.getLong(3)))
                }
            }
        } catch (e: Exception) {
            // немає дозволу або помилка — повертаємо те, що встигли
        }
        return list
    }

    fun setTracks(list: List<Track>) {
        val curId = current?.id
        tracks = list
        index = if (curId != null) list.indexOfFirst { it.id == curId } else -1
        version++
        notifyChange()
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pause()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK ->
                try { mp?.setVolume(0.3f, 0.3f) } catch (e: Exception) {}
            AudioManager.AUDIOFOCUS_GAIN ->
                try { mp?.setVolume(1f, 1f) } catch (e: Exception) {}
        }
    }

    private fun requestFocus() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focusReq = r
        am.requestAudioFocus(r)
    }

    private fun abandonFocus() {
        val r = focusReq ?: return
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.abandonAudioFocusRequest(r)
        focusReq = null
    }

    fun release() {
        mp?.let {
            try {
                it.setOnCompletionListener(null)
                it.setOnErrorListener(null)
                it.release()
            } catch (e: Exception) {}
        }
        mp = null
        prepared = false
    }

    fun stopAll() {
        release()
        abandonFocus()
    }

    fun playIndex(i: Int) {
        val t = tracks.getOrNull(i) ?: return
        index = i
        release()
        requestFocus()
        val p = MediaPlayer()
        mp = p
        prepared = false
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(app, t.uri)
            p.setOnPreparedListener {
                prepared = true
                fails = 0
                it.start()
                notifyChange()
            }
            p.setOnCompletionListener { next(true) }
            p.setOnErrorListener { _, _, _ ->
                onPlayError()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            onPlayError()
        }
        notifyChange()
    }

    private fun onPlayError() {
        if (++fails < 5 && tracks.size > 1) next(true) else {
            release()
            notifyChange()
        }
    }

    fun toggle() {
        val p = mp
        if (p == null || index < 0) {
            if (tracks.isNotEmpty()) playIndex(if (index >= 0) index else 0)
            return
        }
        try {
            if (p.isPlaying) p.pause() else {
                requestFocus()
                p.start()
            }
        } catch (e: Exception) {}
        notifyChange()
    }

    fun pause() {
        try { if (isPlaying) mp?.pause() } catch (e: Exception) {}
        notifyChange()
    }

    fun next(auto: Boolean) {
        if (tracks.isEmpty()) return
        if (auto && repeat == 2 && index >= 0) {
            playIndex(index)
            return
        }
        var n = index + 1
        if (shuffle && tracks.size > 1) {
            do { n = tracks.indices.random() } while (n == index)
        }
        if (n >= tracks.size) {
            if (repeat == 1 || !auto) n = 0 else {
                try { mp?.pause(); mp?.seekTo(0) } catch (e: Exception) {}
                notifyChange()
                return
            }
        }
        playIndex(n)
    }

    fun prev() {
        if (tracks.isEmpty()) return
        if (position > 3000) {
            seek(0)
            return
        }
        playIndex(if (index <= 0) tracks.size - 1 else index - 1)
    }

    fun seek(ms: Int) {
        try { if (prepared) mp?.seekTo(ms) } catch (e: Exception) {}
        notifyChange()
    }
}
